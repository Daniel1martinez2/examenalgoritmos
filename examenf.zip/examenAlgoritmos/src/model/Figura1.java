package model;
import processing.core.PApplet;
public class Figura1 extends Figura{
	
	public Figura1(int posx, int posy ,int r, int g,int b,PApplet app) {
		super(posx,posy,r,g,b,app );
		
	}

	void pintar() {
		app.fill(r,g,b);
		app.ellipse(posx, posy, 100, 100);
		
	}

}
