package model;
import processing.core.PApplet;
import model.Figura;

public class Logic {
	Figura[] fig; 
	String[] cargoTxt;
	PApplet app; 
	String[] separo; 
	
	public Logic(PApplet app) {
		this.app= app; 
		
	}
	
	public void drawScreen() {
		
		cargoTxt = app.loadStrings("../data/text1.txt"); 
		fig = new Figura[7]; 
		
		for (String st : cargoTxt) {
			 separo = st.split(" "); 
			 if(separo[0].equals("Cuadrado")) {
				
				 System.out.println(separo[0]);
				 
				 for (Figura fi : fig) {
					 fi = new Figura1(Integer.parseInt(separo[1]), Integer.parseInt(separo[2]), 3, 3, 3, app); 
				}
				
				 
				 
				
			 }
			 if(separo[0].equals("Circulo")) {
				  System.out.println(separo[0]);
				  for (Figura fi : fig) {
						 fi = new Figura2(Integer.parseInt(separo[1]), Integer.parseInt(separo[2]), 3, 3, 3, app); 
					}
			 }
			 
			 
			 
		}
		
		System.out.println(fig.length);
		
		
	}
	
	public void pintoPantalla() {
	
		for (Figura fi : fig) {
			System.out.println(fi);
			
		}
		
	}
	
	
	

}
