package model;
import processing.core.PApplet;

abstract class Figura {
	protected int posx;
	protected int posy;
	protected int r;
	protected int g;
	protected int b;
	PApplet app; 
	
	public Figura(int posx, int posy, int r, int g, int b,PApplet app) {
		 this.app= app; 
	}
	abstract void pintar();
	public int getPosx() {
		return posx;
	}
	public void setPosx(int posx) {
		this.posx = posx;
	}
	public int getPosy() {
		return posy;
	}
	public void setPosy(int posy) {
		this.posy = posy;
	}
	public int getR() {
		return r;
	}
	public void setR(int r) {
		this.r = r;
	}
	public int getG() {
		return g;
	}
	public void setG(int g) {
		this.g = g;
	}
	public int getB() {
		return b;
	}
	public void setB(int b) {
		this.b = b;
	} 

}
