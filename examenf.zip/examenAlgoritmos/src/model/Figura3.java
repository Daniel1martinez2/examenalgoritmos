package model;
import processing.core.PApplet;
public class Figura3 extends Figura {
	public Figura3(int posx, int posy ,int r, int g,int b,PApplet app ) {
		super(posx,posy,r,g,b,app); 
	}


	void pintar() {
		app.fill(r,g,b);
		
		
	}

}
