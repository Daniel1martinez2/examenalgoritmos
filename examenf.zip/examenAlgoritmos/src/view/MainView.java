package view;

import processing.core.PApplet;
import controller.Controller;
public class MainView extends PApplet {
	Controller con; 
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PApplet.main("view.MainView");

	}
	
	public void settings() {
		size(400,400); 
	}
	public void setup() {
		con = new Controller(this); 
		con.setupScreen();
	}
	public void draw() {
		background( 255); 
		con.pinarpantalla();
		
	}

}
