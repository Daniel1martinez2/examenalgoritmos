package controller;
import model.Logic;
import processing.core.PApplet;

public class Controller {
	PApplet app; 
	Logic logi; 
	public Controller(PApplet app) {
		this.app= app; 
		logi = new Logic(app); 
		
	}
	
	public void setupScreen() {
		logi.drawScreen();
	}
	public void pinarpantalla() {
		logi.pintoPantalla();
	}

	
}
